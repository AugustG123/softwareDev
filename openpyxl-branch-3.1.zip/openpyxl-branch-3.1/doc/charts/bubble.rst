Bubble Charts
=============

Bubble charts are similar to scatter charts but use a third dimension to determine the size of the bubbles.
Charts can include multiple series.

.. literalinclude:: bubble.py


This will produce a bubble chart with two series and should look something like this:

.. image:: bubble.png
   :alt: "Sample bubble chart"
