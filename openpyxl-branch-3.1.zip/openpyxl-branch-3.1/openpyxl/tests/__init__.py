# Copyright (c) 2010-2023 openpyxl

import os

KEEP_VBA = os.environ.get("OPENPYXL_KEEP_VBA", "False") == "True"
